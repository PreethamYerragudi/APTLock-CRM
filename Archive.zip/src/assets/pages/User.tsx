var assignedLocation = "Miyapur";

export default function getLocation(){
    return assignedLocation;
}

function setLocation(location: string){
    assignedLocation = location;
}

